###############################################################################
# Copyright (c) 2024 MyTorch Systems Inc. All rights reserved.
###############################################################################

class ParametersGenerator:
    def __init__(self, uuid: str):
        self.uuid = uuid