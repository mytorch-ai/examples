###############################################################################
# Copyright (c) 2024 MyTorch Systems Inc. All rights reserved.
###############################################################################

"""
This singleton class gets the gRPC connection to the server.
"""
import grpc
from utils.logger import Logger
import time
from MyTorchClient import MyTorchClient
import signal
import sys
import atexit
import threading

###########################################################################
#### ServerConnection; only has one connection to the server
#### All methods are class methods.
#### _connection_is_active is thread safe; if True, all subsequent calls are ignored
###########################################################################

class ServerConnection:
    _lock = threading.Lock() # lock to ensure that only one thread can access the connection at a time
    _channel = None
    _server = None
    _port = 50051 # default
    _connection_is_active = False # set to True when disconnect is called so all subsequent calls are ignored

    @classmethod
    def get_server_ip(cls):
        return cls._server, cls._port

    @classmethod
    def close_connection(cls):
        with cls._lock:
            cls._connection_is_active = True

    @classmethod
    def open_connection(cls):
        with cls._lock:
            cls._connection_is_active = False

    @classmethod
    def is_connection_active(cls):
        with cls._lock:
            return cls._connection_is_active

    @classmethod
    def get_active_connection(cls):
        """
        If there is no connection, or if the server or port has changed, then reconnect
        If there is an existing connection, return it
        """

        # Ask the Client-side MyTorch singleton for the server to use.
        _, new_server, new_port = MyTorchClient.instance().select_server_by_env_var()
        
        # If it's the first call, or if a new server or port, then reconnect.
        if cls._channel is None or cls._server != new_server or cls._port != new_port:
            cls._server, cls._port = new_server, new_port
            cls._connection_is_active = False
            # Create a channel with the server
            channel = grpc.insecure_channel(cls._server + ":" + str(cls._port))

            # Define the metadata to be added
            client_id = MyTorchClient.instance().get_client_id()
            metadata = [('client_id', client_id)]

            register_cleanup_handlers()

            """
            ... currently don't need this, but this is how you would add more metadata
            to the connection.
            
            client_info = MyTorchClient.instance().get_client_info()
            metadata.extend([
                ('hostname', client_info['hostname']),
                ('local_ip', client_info['local_ip']),
                ('os_name', client_info['os_name']),
                ('os_version', client_info['os_version']),
                ('os_release', client_info['os_release']),
                ('os_details', client_info['os_details']),
                ('machine', client_info['machine']),
                ('processor', client_info['processor']),
            ])
            """

            metadata_interceptor = MetadataInterceptor(metadata)
            logging_interceptor = LoggingInterceptor()

            # Add the interceptors to the channel
            try:
                ServerConnection._channel = grpc.intercept_channel(channel, logging_interceptor, metadata_interceptor)
                ServerConnection.open_connection()
                Logger.get_logger().info(f"Connecting to server {cls._server}:{cls._port}")
            except Exception as e:
                Logger.get_logger().error(f"Error connecting to server {cls._server}:{cls._port}")
                Logger.get_logger().error(f"Error details: {e}")
                exit(1)
        return ServerConnection._channel

###########################################################################
#### Interceptor to add metadata (e.g. Client UUID) to each outgoing request
###########################################################################
class MetadataInterceptor(
    grpc.UnaryUnaryClientInterceptor,
    grpc.UnaryStreamClientInterceptor,
    grpc.StreamUnaryClientInterceptor,
    grpc.StreamStreamClientInterceptor
):
    def __init__(self, metadata):
        self._metadata = metadata

    def intercept_unary_unary(self, continuation, client_call_details, request):
        new_details = self._augment_metadata(client_call_details)
        return continuation(new_details, request)

    def intercept_unary_stream(self, continuation, client_call_details, request):
        new_details = self._augment_metadata(client_call_details)
        return continuation(new_details, request)

    def intercept_stream_unary(self, continuation, client_call_details, request_iterator):
        new_details = self._augment_metadata(client_call_details)
        return continuation(new_details, request_iterator)

    def intercept_stream_stream(self, continuation, client_call_details, request_iterator):
        new_details = self._augment_metadata(client_call_details)
        return continuation(new_details, request_iterator)

    def _augment_metadata(self, client_call_details):
        new_metadata = []
        if client_call_details.metadata is not None:
            new_metadata = list(client_call_details.metadata)
        new_metadata.extend(self._metadata)

        # Use the named tuple to create new client call details
        return _ClientCallDetails(
            method=client_call_details.method,
            timeout=client_call_details.timeout,
            credentials=client_call_details.credentials,
            metadata=new_metadata,
            wait_for_ready=client_call_details.wait_for_ready,
            compression=client_call_details.compression
        )

# Define a named tuple to represent the client call details
from collections import namedtuple
_ClientCallDetails = namedtuple(
    '_ClientCallDetails',
    ['method', 'timeout', 'credentials', 'metadata', 'wait_for_ready', 'compression']
)

###########################################################################
#### Interceptor to add client-side logging of gRPC calls
###########################################################################
class LoggingInterceptor(grpc.UnaryUnaryClientInterceptor,
                         grpc.UnaryStreamClientInterceptor,
                         grpc.StreamUnaryClientInterceptor,
                         grpc.StreamStreamClientInterceptor):
    def __init__(self):
        self.logger = Logger.get_logger()

    def intercept_unary_unary(self, continuation, client_call_details, request):
        return self._intercept_call(continuation, client_call_details, request)

    def intercept_unary_stream(self, continuation, client_call_details, request):
        return self._intercept_call(continuation, client_call_details, request)

    def intercept_stream_unary(self, continuation, client_call_details, request_iterator):
        return self._intercept_stream_call(continuation, client_call_details, request_iterator)

    def intercept_stream_stream(self, continuation, client_call_details, request_iterator):
        return self._intercept_stream_call(continuation, client_call_details, request_iterator)

    def _intercept_call(self, continuation, client_call_details, request):
        # this will be intercepted by the @wrap_with_error_handler decorator and ignored
        if ServerConnection.is_connection_active():
            raise IgnoredGrpcCallException("Connection already closed; ignoring gRPC call.")
        method_name = client_call_details.method
        self.logger.debug(f"~~~~~~~~~ Outgoing request ~~~~~~~~~")
        self.logger.debug(f"Calling gRPC method: {method_name}")

        start_time = time.perf_counter()
        response = continuation(client_call_details, request)
        self._log_duration(method_name, start_time)
        self._log_response(method_name, response)
        return response

    def _intercept_stream_call(self, continuation, client_call_details, request_iterator):
        # this will be intercepted by the @wrap_with_error_handler decorator and ignored
        if ServerConnection.is_connection_active():
            raise IgnoredGrpcCallException("Connection already closed; ignoring gRPC call.")

        method_name = client_call_details.method
        self.logger.debug(f"~~~~~~~~~ Outgoing stream request ~~~~~~~~~")
        self.logger.debug(f"Calling gRPC streaming method: {method_name}")

        start_time = time.perf_counter()

        # Wrap the request iterator to add logging
        wrapped_iterator = self._log_stream_requests(request_iterator)

        response = continuation(client_call_details, wrapped_iterator)
        self._log_duration(method_name, start_time)
        self._log_response(method_name, response)
        return response

    def _log_duration(self, method_name, start_time):
        end_time = time.perf_counter()
        duration = end_time - start_time
        rounded_duration = round(1000 * duration, 2)  # Convert to milliseconds and round to 2 decimal places
        self.logger.debug(f"Method {method_name} took: {rounded_duration} ms")
        MyTorchClient.instance().add_method_duration(method_name, duration)
        return duration

    def _log_response(self, method_name, response):
        self.logger.debug("~~~~~~~~~ Incoming response ~~~~~~~~~")
        self.logger.debug(f"Received gRPC method: {method_name}")
        self.logger.debug("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        return response

    def _log_stream_requests(self, request_iterator):
        for request in request_iterator:
            self.logger.debug(f"Streaming request: {request}")
            yield request

###########################################################################
#### this provides a central place to handle gRPC errors
###########################################################################
# Custom exception to indicate that the gRPC call should be ignored.
class IgnoredGrpcCallException(Exception):
    pass


def wrap_with_error_handler(method):
    from gRPC_impl.shared_msg_types_pb2 import Empty
    logger = Logger.get_logger()

    def wrapper(*args, **kwargs):
        try:
            return method(*args, **kwargs)
        except IgnoredGrpcCallException:  # currently only used for connection close
            return Empty()  # Return a default response or an appropriate response for your method
        except grpc.RpcError as e:
            server, port = ServerConnection.get_server_ip()
            status_code = e.code()
            logger.error(f"Error calling server {server}:{port}")
            logger.error(f"Failed calling method {method.__module__}.{method.__name__}")
            if status_code == grpc.StatusCode.UNAVAILABLE:
                logger.error(f"Please ensure the server is active and reachable.")
                exit(1)
            elif status_code == grpc.StatusCode.INVALID_ARGUMENT:
                logger.error(f"Invalid argument provided to gRPC method {method.__name__}")
                exit(1)
            else:
                logger.error(f"Error details: {e.details()}")
                exit(1)
        except Exception as e:
            if not isinstance(e, grpc.RpcError):  # Ensure it's not a grpc.RpcError
                logger.error(f"Error calling server: {method.__module__}.{method.__name__}")
                logger.error(f"Details: {str(e)}")
                exit(1)

    return wrapper



###########################################################################
#### Handle client kill/end by telling server we are disconnecting
###########################################################################
# this is called when the client is cleanly disconnected
def disconnect():
    if not ServerConnection.is_connection_active():
        return
    try:
        grpc_disconnect()
        Logger.get_logger().info("Disconnected from server.")
    except:
        pass  # Silently handle any errors during disconnect
    finally:
        ServerConnection.close_connection()

@ wrap_with_error_handler
def grpc_disconnect():
    from mytorch.scaffolding.server_mgmt import client_disconnect
    client_disconnect()

# This is called when the client is forced-quit by the user
def handle_signal(signal, frame):
    disconnect()
    sys.exit(0)

def register_cleanup_handlers():
    # Register signal handlers
    # call disconnect() when the client is forced-quit by the user
    signal.signal(signal.SIGINT, handle_signal)
    signal.signal(signal.SIGTERM, handle_signal)

    # Register atexit function
    # call disconnect() when the client is cleanly disconnected
    atexit.register(disconnect)

