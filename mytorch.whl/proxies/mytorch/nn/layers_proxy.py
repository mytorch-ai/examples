###############################################################################
# Copyright (c) 2024 MyTorch Systems Inc. All rights reserved.
###############################################################################

from enum import Enum, auto

############################################
# LayerType enum
############################################
class LayerType(Enum):
    LINEAR = auto()
    RELU = auto()
    FLATTEN = auto()
    # Add other layer types as needed

class LayerProxy:
    def __init__(self, layer_type: LayerType, **params):
        self.layer_type = layer_type
        self.params = params

    def print(self):
        print(f"Layer type: {self.layer_type.name}, Params: {self.params}")

    def describe(self):
        return f"Layer type: {self.layer_type.name}, Params: {self.params}"

class LinearProxy(LayerProxy):
    def __init__(self, in_features, out_features):
        super().__init__(LayerType.LINEAR, in_features=in_features, out_features=out_features)

from proxies.mytorch.mytorch_proxy import MyTorchProxy

class ReLUProxy(LayerProxy):
    def __init__(self):
        super().__init__(LayerType.RELU)


    def forward(self, tensor):
        """Calls ReLU on the server via generic_call."""
        return MyTorchProxy().generic_call("torch.nn", "ReLU", tensor.uuid)
    
class FlattenProxy(LayerProxy):
    def __init__(self):
        super().__init__(LayerType.FLATTEN)
