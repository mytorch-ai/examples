###############################################################################
# Copyright (c) 2024 MyTorch Systems Inc. All rights reserved.
###############################################################################

from proxies.mytorch.nn.functional.functional_proxy import FunctionalProxy
from torch.Tensor import Tensor


# Parameters
#         input (Tensor) – input
#         dim (int) – A dimension along which softmax will be computed.
#         dtype (torch.dtype, optional) – the desired data type of returned tensor. Default: None.
#
# Return type
#     Tensor
def softmax(input: Tensor, dim: int) -> Tensor:
    proxy = FunctionalProxy()
    return proxy.softmax(input, dim)